---
marp: true
theme: default
paginate: true
size: 16:9
html: true
---

<style>
section.img {
  display: flex;
  justify-content: center;
  align-items: center;
}
section.img img {
  display: block;
  margin: auto;
  max-width: 90%;
  max-height: 90%;
}
</style>

# Индивидуальный проект на HUGO 
## Архитектура компьютеров и операционные системы  
### Разработка персонального сайта на Hugo

**Выполнил:** Козин Иван Евгеньевич  
**Группа:** НКАбд-03-25  

---

# Цель работы

Освоение генератора статических сайтов Hugo.  
Разработка персонального сайта и его размещение на GitHub Pages.

---

# Используемые технологии

- Hugo (SSG)
- Wowchemy (шаблон)
- Git / GitHub
- Markdown
- Node.js (доп. инструменты)

---

# 1. Установка окружения

- Установлен Hugo  
- Проверена установка (`hugo version`)  
- Установлены Node.js и npm  

---

# 2. Создание проекта

Создан сайт с использованием шаблона Wowchemy:

git clone starter-hugo-academic  
cd my-site  
hugo server  

---

# 3. Настройка конфигурации

Изменён параметр:

baseURL: https://GEAR-company-offical.github.io/my-site/

Настроен язык сайта и структура URL.

---

# 4. Настройка профиля

Заполнены данные:

- имя  
- описание  
- интересы  
- образование  
- навыки  

---

<!-- _class: img -->
![](src/image.png)

---

![](src/image-1.png)

---



# 5. Добавление контента

Созданы посты:

hugo new content/post/post1.md  

Добавлены статьи и информация о проекте.

---

![](src/image-2.png)

---

# 6. Работа с GitHub

- создан репозиторий  
- выполнен push  
- настроен GitHub Pages  


---

![](src/image-3.png)

---

# 7. Деплой сайта

Сайт размещён на GitHub Pages  
Проверена доступность по URL  


---

![](src/image-4.png)


---

# 8. Двуязычность

Настроены языки:

- русский  
- английский  

Изменена структура URL.



---

![](src/image-5.png)


---


![](src/image-6.png)

---

# Вывод

- Освоен Hugo  
- Создан персональный сайт  
- Настроен деплой через GitHub  
- Реализована структура контента  
- Получены навыки веб-разработки  

---

# Спасибо за внимание